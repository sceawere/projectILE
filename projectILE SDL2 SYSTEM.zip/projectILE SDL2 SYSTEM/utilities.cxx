#include "text_utils.h"

TextObject CreateText(SDL_Renderer* renderer, TTF_Font* font,
                      const std::string& text, SDL_Color color,
                      int x, int y)
{
    TextObject obj{};
    SDL_Surface* surf = TTF_RenderText_Blended(font, text.c_str(), color);
    if (!surf) {
        SDL_Log("❌ TTF_RenderText_Blended error: %s", TTF_GetError());
        return obj;
    }

    obj.texture = SDL_CreateTextureFromSurface(renderer, surf);
    if (!obj.texture) {
        SDL_Log("❌ SDL_CreateTextureFromSurface error: %s", SDL_GetError());
        SDL_FreeSurface(surf);
        return obj;
    }

    SDL_QueryTexture(obj.texture, NULL, NULL, &obj.rect.w, &obj.rect.h);
    obj.rect.x = x;
    obj.rect.y = y;

    SDL_FreeSurface(surf);
    return obj;
}

int sdl_quit() {
	SDL_Window* window = nullptr;
    SDL_Renderer* renderer = nullptr;
    SDL_Texture* image = nullptr;
    SDL_Texture* textTexture = nullptr;
    TTF_Font* font = nullptr;
    SDL_Surface* surface = nullptr;
    Mix_Chunk* buttonSound = nullptr;
	
	SDL_StopTextInput();
	SDL_FreeSurface(surface);
	SDL_DestroyTexture(textTexture);
	TTF_CloseFont(font);
	SDL_DestroyTexture(image);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    Mix_FreeChunk(buttonSound);
	Mix_CloseAudio();
    TTF_Quit();
    SDL_Quit();
    IMG_Quit();
    std::cout << "👋 Closing projectILE. Have a good day!\n";
    return 0;
}
