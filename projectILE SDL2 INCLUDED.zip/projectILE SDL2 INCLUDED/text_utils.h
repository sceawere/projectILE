#pragma once
#include "SDL2/include/SDL2/SDL.h"
#include "SDL2/include/SDL2/SDL_ttf.h"
#include <string>

struct TextObject {
    SDL_Texture* texture;
    SDL_Rect rect;
};

TextObject CreateText(SDL_Renderer* renderer, TTF_Font* font,
                      const std::string& text, SDL_Color color,
                      int x, int y);
